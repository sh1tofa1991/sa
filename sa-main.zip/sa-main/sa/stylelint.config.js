export { stylelint as default } from 'vue-linters-config';
