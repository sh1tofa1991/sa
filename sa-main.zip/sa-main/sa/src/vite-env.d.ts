/* eslint-disable unicorn/filename-case */
/// <reference types="vite/client" />
