<template>
  <div>Тут что-то будет!</div>
</template>
