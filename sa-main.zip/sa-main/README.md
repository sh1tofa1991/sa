# СА

https://github.com/dergunovs/sa

Открыть терминал. в нём написать:
git clone https://github.com/dergunovs/sa.git

Открыть vs code, в нём открыть появившуюся папку с проектом

Открыть терминал, в нём написать:
npm install

Также в настройках vs code включить форматирование кода при сохранении.

---

Внутри VS code установить 4 плагина: eslint, stylelint, prettier, vue official

Помощь: qwen 3 coder
