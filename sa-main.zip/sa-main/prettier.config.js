export { prettier as default } from 'vue-linters-config';
