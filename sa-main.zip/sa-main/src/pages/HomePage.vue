<template>
  <div class="home-page">
    <SubnetCalculator />
  </div>
</template>

<script setup lang="ts">
import SubnetCalculator from '@/components/SubnetCalculator.vue';
</script>

<style scoped>
.home-page {
  padding: 20px;
  background-color: #fafafa;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: flex-start;
}
</style>