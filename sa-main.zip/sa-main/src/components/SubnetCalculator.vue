<template>
  <div class="calculator">
    <h2>Калькулятор подсетей</h2>

    <div class="input-group">
      <label for="ip">IP адрес:</label>
      <input
        id="ip"
        v-model="ipInput"
        type="text"
        placeholder="192.168.1.150"
        @keyup.enter="calculate"
      />
      <span v-if="!isIpValidComputed" class="error">Некорректный IP-адрес</span>
    </div>

    <div class="input-group">
      <label for="mask">Маска сети:</label>
      <select id="mask" v-model="selectedMask">
        <option v-for="option in MASK_OPTIONS" :key="option.value" :value="option.value">
          {{ option.label }}
        </option>
      </select>
    </div>

    <button
      :disabled="!isIpValidComputed"
      @click="calculate"
      class="btn-calculate"
    >
      Рассчитать
    </button>

    <div v-if="result" class="result">
      <h3>Результат:</h3>
      <p><strong>IP адрес:</strong> {{ ipInput }}</p>
      <p><strong>Маска:</strong> {{ selectedMask }}</p>
      <p><strong>Адрес сети:</strong> {{ result.networkAddress }}</p>
      <p><strong>Количество адресов:</strong> {{ result.addressesCount }}</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { isIpValid } from '@/utils/validation';
import { getNetworkAdress } from '@/utils/network';
import { getAddressesCount } from '@/utils/mask';
import { MASK_OPTIONS } from '@/constants/masks';

const ipInput = ref('');
const selectedMask = ref(MASK_OPTIONS[24].value); // по умолчанию /24
const result = ref<{ networkAddress: string; addressesCount: number } | null>(null);

const isIpValidComputed = computed(() => {
  return isIpValid(ipInput.value);
});

function calculate() {
  if (!isIpValidComputed.value) return;

  const networkAddress = getNetworkAdress(ipInput.value, selectedMask.value);
  const addressesCount = getAddressesCount(selectedMask.value);

  result.value = {
    networkAddress,
    addressesCount,
  };
}
</script>

<style scoped>
.calculator {
  max-width: 500px;
  margin: 0 auto;
  padding: 20px;
  background-color: var(--bg-color, #f9f9f9);
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.input-group {
  margin-bottom: 16px;
  display: flex;
  flex-direction: column;
}

label {
  margin-bottom: 4px;
  font-weight: bold;
  color: var(--text-color, #333);
}

input,
select {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
}

.error {
  color: red;
  font-size: 14px;
  margin-top: 4px;
}

.btn-calculate {
  padding: 10px 20px;
  background-color: var(--primary-color, #007bff);
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  margin-top: 10px;
}

.btn-calculate:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

.result {
  margin-top: 20px;
  padding: 16px;
  background-color: #e9f7ef;
  border-left: 4px solid #28a745;
  border-radius: 4px;
}

.result p {
  margin: 8px 0;
}
</style>